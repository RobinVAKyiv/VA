let http = require('http');

//create a server object:
http.createServer(function (req, res) {
    //res.write('Hello World!'); //write a response to the client
    
    // res.end({"message":"hello world"}); //end the response
    
    res.end('Hello!'); //end the response
}).listen(1337, '127.0.0.1'); //the server object listens on port 8080

// https://stackoverflow.com/questions/20035101/why-does-my-javascript-get-a-no-access-control-allow-origin-header-is-present